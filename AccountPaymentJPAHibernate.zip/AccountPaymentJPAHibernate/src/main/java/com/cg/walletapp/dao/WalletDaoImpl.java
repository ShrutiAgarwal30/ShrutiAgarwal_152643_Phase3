package com.cg.walletapp.dao;

import javax.persistence.EntityManager;

import com.cg.walletapp.bean.Customer;

import com.cg.walletapp.exception.WalletException;

public class WalletDaoImpl implements IWalletDao {
	private EntityManager entityManager;

	public WalletDaoImpl() {
		entityManager = JPAUtil.getEntityManager();

	}

	public void addAccountDao(Customer customer) throws WalletException {

		entityManager.persist(customer);
	}

	public Customer findOne(String mobnum) throws WalletException {
		Customer customer = entityManager.find(Customer.class, mobnum);
		return customer;

	}

	public boolean checkMobno(String mobnum) throws WalletException {
		boolean flag = false;
		Customer customer = entityManager.find(Customer.class, mobnum);
		if (customer != null) {
			flag = true;
		}

		return flag;

	}

	public void updateBalance(Customer customerinfo) throws WalletException {
		entityManager.merge(customerinfo);
	}

	public void beginTransaction() {
		entityManager.getTransaction().begin();

	}

	public void commitTransaction() {
		entityManager.getTransaction().commit();

	}

}