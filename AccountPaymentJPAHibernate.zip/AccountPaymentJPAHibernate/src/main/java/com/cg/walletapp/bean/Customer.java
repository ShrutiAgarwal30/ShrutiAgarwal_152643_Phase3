package com.cg.walletapp.bean;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "WalletApp")
public class Customer {
	@Column(name = "NAME", length = 20)
	private String name;
	@Id
	@Column(name = "MOBILE", length = 10)
	private String mobileNo;

	@Embedded
	private Wallet wallet;

	public Customer() {
		wallet = new Wallet();
	}

	public BigDecimal getWalletBalance() {
		return wallet.getBalance();
	}

	public void setWalletBalance(BigDecimal amount) {
		wallet.setBalance(amount);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Override
	public String toString() {
		return "Customer name=" + name + ", mobileNo=" + mobileNo + wallet.getBalance();
	}
}
