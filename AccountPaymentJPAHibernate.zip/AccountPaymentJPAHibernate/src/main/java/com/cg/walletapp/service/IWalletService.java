package com.cg.walletapp.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.walletapp.bean.Customer;
import com.cg.walletapp.bean.Transaction;
import com.cg.walletapp.exception.WalletException;

public interface IWalletService {
	public void addAccount(Customer customer) throws WalletException;

	public boolean checkMobno(String mobnum) throws WalletException;

	public Customer showBalance(String mobnum) throws WalletException;

	public BigDecimal transferFund(String mobnum, String mobnumber, BigDecimal transferamount) throws WalletException;

	public BigDecimal depositBalance(String mobnum, BigDecimal amount1) throws WalletException;

	public BigDecimal withdrawal(String mobnum, BigDecimal amount2) throws WalletException;

	public boolean validateRechargeAmount(String mobnum, BigDecimal amount2)throws WalletException;

	public boolean validateDetails(String name, String mnumber) throws WalletException;

	public List<Transaction> printTransactionDetails(String mobnum) throws WalletException;
}
