package com.cg.walletapp.service;

import java.math.BigDecimal;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.cg.walletapp.bean.Customer;
import com.cg.walletapp.bean.Transaction;
import com.cg.walletapp.dao.IWalletDao;
import com.cg.walletapp.dao.IWalletTransactionDao;
import com.cg.walletapp.dao.WalletDaoImpl;
import com.cg.walletapp.dao.WalletTransactionDaoImpl;
import com.cg.walletapp.exception.IWalletException;
import com.cg.walletapp.exception.WalletException;

public class WalletService implements IWalletService {
	IWalletDao dao = new WalletDaoImpl();
	IWalletTransactionDao transdao = new WalletTransactionDaoImpl();
	DateTimeFormatter formatter= DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	public void addAccount(Customer customer) throws WalletException {
		dao.beginTransaction();
		dao.addAccountDao(customer);
		dao.commitTransaction();
	}

	public boolean checkMobno(String mobnum) throws WalletException {

		return dao.checkMobno(mobnum);
	}

	public Customer showBalance(String mobnum) throws WalletException {

		Customer customerinfo = dao.findOne(mobnum);

		return customerinfo;

	}

	public BigDecimal transferFund(String mobnum, String mobnumber, BigDecimal transferamount) throws WalletException {

		Customer customerinfo = dao.findOne(mobnum);
		Customer customerinfo2 = dao.findOne(mobnumber);
		BigDecimal amount1 = customerinfo.getWalletBalance();
		BigDecimal amount2 = customerinfo2.getWalletBalance();
		amount1 = amount1.subtract(transferamount);
		customerinfo.setWalletBalance(amount1);
		dao.beginTransaction();
		dao.updateBalance(customerinfo);
		dao.commitTransaction();
		BigDecimal finalamount = amount2.add(transferamount);
		customerinfo2.setWalletBalance(finalamount);
		dao.beginTransaction();
		dao.updateBalance(customerinfo2);
		dao.commitTransaction();
		Transaction transactioninfo = new Transaction();
		transactioninfo.setMobnum(mobnum);
		transactioninfo.setTransaction("FundTransfered" + transferamount + " to- " + mobnumber);
		
		LocalDateTime localdateTime=LocalDateTime.now();
		transactioninfo.setTime(localdateTime.format(formatter));
		transdao.beginTransaction();
		transdao.addTransactions(transactioninfo);
		transdao.commitTransaction();
		return customerinfo.getWalletBalance();
	}

	public BigDecimal depositBalance(String mobnum, BigDecimal amount1) throws WalletException {
		Customer customerinfo = dao.findOne(mobnum);
		BigDecimal amountnew = customerinfo.getWalletBalance();
		BigDecimal amountdeposit = amountnew.add(amount1);
		customerinfo.setWalletBalance(amountdeposit);
		dao.beginTransaction();
		dao.updateBalance(customerinfo);
		dao.commitTransaction();
		Transaction transactioninfo = new Transaction();
		transactioninfo.setMobnum(mobnum);
		transactioninfo.setTransaction("Deposited Amount " + amount1);
		LocalDateTime localdateTime=LocalDateTime.now();
		transactioninfo.setTime(localdateTime.format(formatter));
		transdao.beginTransaction();
		transdao.addTransactions(transactioninfo);
		transdao.commitTransaction();

		return customerinfo.getWalletBalance();

	}

	public BigDecimal withdrawal(String mobnum, BigDecimal amount2) throws WalletException {

		Customer customerinfo = dao.findOne(mobnum);
		BigDecimal amountnew1 = customerinfo.getWalletBalance();
		BigDecimal amountwithdraw = amountnew1.subtract(amount2);
		customerinfo.setWalletBalance(amountwithdraw);
		dao.beginTransaction();
		dao.updateBalance(customerinfo);
		dao.commitTransaction();
		Transaction transactioninfo = new Transaction();
		transactioninfo.setMobnum(mobnum);
		transactioninfo.setTransaction("Amount WithDrawn " + amount2);
		LocalDateTime localdateTime=LocalDateTime.now();
		transactioninfo.setTime(localdateTime.format(formatter));
		transdao.beginTransaction();
		transdao.addTransactions(transactioninfo);
		transdao.commitTransaction();

		return customerinfo.getWalletBalance();

	}

	public boolean validateDetails(String name, String mnumber) throws WalletException {
		boolean output = false;
		if (name.trim().matches("^[a-zA-Z]{1,15}$")) {
			if (mnumber.matches("[0-9]") || mnumber.length() == 10) {
				output = true;
			} else {

				throw new WalletException(IWalletException.ERROR1);
			}
		} else {
			throw new WalletException(IWalletException.ERROR1);
		}

		return output;
	}

	public boolean validateRechargeAmount(String mobnum, BigDecimal amount2) throws WalletException {
		boolean output = false;
		Customer customerinfo = dao.findOne(mobnum);
		BigDecimal amount = customerinfo.getWalletBalance();
		if (amount2.compareTo(new BigDecimal(0)) < 0 || amount2.compareTo(amount) == -1
				|| amount2.compareTo(amount) == 0) {
			output = true;
		} else {
			throw new WalletException(IWalletException.ERROR2);
		}
		return output;
	}

	public List<Transaction> printTransactionDetails(String mobnum) throws WalletException {
		return transdao.printTransactionsDao(mobnum);
	}
}
