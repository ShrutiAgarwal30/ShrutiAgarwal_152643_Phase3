package com.cg.walletapp.dao;

import java.util.List;

import com.cg.walletapp.bean.Transaction;

public interface IWalletTransactionDao {

	public List<Transaction> printTransactionsDao(String mobnum);

	public void addTransactions(Transaction transactioninfo);
	void beginTransaction();

	void commitTransaction();
}
