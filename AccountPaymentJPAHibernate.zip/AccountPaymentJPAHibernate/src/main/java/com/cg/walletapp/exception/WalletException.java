package com.cg.walletapp.exception;

public class WalletException extends Exception {
	
	private static final long serialVersionUID = 1L;
	WalletException(){
		super();
	}
public WalletException(String msg){
	super(msg);
}
}
