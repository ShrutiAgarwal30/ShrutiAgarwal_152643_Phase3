package com.cg.walletapp.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="bank")
@NamedQueries(@NamedQuery(name = "getAllTransactions", query = "SELECT bank from Transaction bank"))
public class Transaction implements Serializable {
	private static final long serialVersionUID = 1L;
	
	String mobnum;
	@Column(name = "Transaction", length = 50)
	String transaction;
	@Id
	@Column(name = "time", length = 50)
	String time;

	public String getMobnum() {
		return mobnum;
	}

	public void setMobnum(String mobnum) {
		this.mobnum = mobnum;
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String localDateTime) {
		this.time = localDateTime;
	}

	@Override
	public String toString() {
		return "Transaction [mobnum=" + mobnum + ", transaction=" + transaction + ", time=" + time + "]";
	}

}
