package com.cg.walletapp.dao;

import java.util.List;

import javax.persistence.EntityManager;

import javax.persistence.TypedQuery;

import com.cg.walletapp.bean.Transaction;

public class WalletTransactionDaoImpl implements IWalletTransactionDao {

	private EntityManager entityManagernew;

	public WalletTransactionDaoImpl() {
		entityManagernew = JPAUtil.getEntityManager();
	}

	public void addTransactions(Transaction transactioninfo) {
		entityManagernew.persist(transactioninfo);

	}
		
	public List<Transaction> printTransactionsDao(String mobnum) {
		String qStr = "SELECT bank from Transaction bank WHERE bank.mobnum= :mob";
		TypedQuery<Transaction> query = entityManagernew.createQuery(qStr, Transaction.class);
		query.setParameter("mob", mobnum);

		List<Transaction> bookList = query.getResultList();
		return bookList;
	}

	public void beginTransaction() {
		entityManagernew.getTransaction().begin();

	}

	public void commitTransaction() {
		entityManagernew.getTransaction().commit();

	}

}
