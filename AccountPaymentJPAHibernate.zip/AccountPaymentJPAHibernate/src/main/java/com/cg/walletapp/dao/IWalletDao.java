package com.cg.walletapp.dao;

import com.cg.walletapp.bean.Customer;

import com.cg.walletapp.exception.WalletException;

public interface IWalletDao {

	public void addAccountDao(Customer customer) throws WalletException;

	public Customer findOne(String mobnum) throws WalletException;

	public boolean checkMobno(String mobnum) throws WalletException;

	public void updateBalance(Customer customerinfo) throws WalletException;

	void beginTransaction();

	void commitTransaction();

}
